
# **Data Processing With Python**
### **Contents**
I. Trend Of Programming Languages

II. Why Python?

III. Some Python Basics

IV. "Talk is cheap. Show me the code."

V. Packages We Use

VI. Pandas

VII. Numpy And Matplotlib

VIII. Jupyter Notebook

IX. How To Get Python And Packages?

X. How To Get Help When Coding?

Let`s Play With Python

Recommanded Solutions

## I. Trend Of Programming Languages
### 1. [TIOBE Index](https://tiobe.com/tiobe-index/)
The TIOBE Programming Community index is an indicator of the popularity of programming languages. The index is updated once a month. The ratings are based on the number of skilled engineers world-wide, courses and third party vendors. Popular search engines such as Google, Bing, Yahoo!
![indexOfFeb2018](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/indexOfFeb2018.png?raw=true "indexOfFeb2018")
### 2. Long Term History Of Most Popular Languages
![longTermHistory](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/longTermHistory.png?raw=true "longTermHistory")

## II. Why Python？
![pythonLogo](https://www.python.org/static/img/python-logo.png "pythonLogo")
### *The Zen Of Python*

*Beautiful is better than ugly.*

*Explicit is better than implicit.*

*Simple is better than complex.*

*Complex is better than complicated.*

*Flat is better than nested.*

*Sparse is better than dense.*

*Readability counts.*

*...*

### Summary
* Friendly syntax >>> Easy to learn >>> Fast to develop a project


* Open >>> Powerful (numerous packages, 131315 packages in March 6th, 2018 in total)


* Plays well with others (Glue language: Cython, Rpy2, Jython, PyMongo)


* Cloud computing, Machine Learning, Data Mining, Natural Language Processing, etc.

## III. Some Python Basics
### 1. Language Style
![languageStyle](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/languageStyle.png?raw=true "languageStyle")
### 2. Module


```python
import pandas
df = pandas.DataFrame()
```


```python
import pandas as pd
df = pd.DataFrame()
```


```python
from pandas import *
df = DataFrame()
```


```python
from pandas import DataFrame
df = DataFrame()
```


```python
from pandas import DataFrame as DF
df = DF()
```

### 3. Type Of Data


```python
num = 3 # number, includes int、float、bool and complex
print num, type(num)
```

    3 <type 'int'>
    


```python
list_ = ['Fibonacci', 1, 1, 2, 3, 5, 8] # list
print list_, type(list_)
```

    ['Fibonacci', 1, 1, 2, 3, 5, 8] <type 'list'>
    


```python
str_ = 'Hello' # str
print str_, type(str_)
```

    Hello <type 'str'>
    


```python
tuple_ = (10, 'a') # tuple
print tuple_, type(tuple_)
```

    (10, 'a') <type 'tuple'>
    


```python
dict_= {'key1':'value1', 'key2':'value2', 'key3':'value3'} # dictionary
print dict_, type(dict_)
```

    {'key3': 'value3', 'key2': 'value2', 'key1': 'value1'} <type 'dict'>
    


```python
set_ = {1, 2, 1, 3} # set
print set_, type(set_)
```

    set([1, 2, 3]) <type 'set'>
    

### 4. Operators
Arithmetic Operators: +, -, /, %, **, //

Comparison Operators: ==, !=, >=, <=, >, <

Assignment Operators: =, +=, -=, /=, %=, **=, //=

Bitwise Operators: &, |, ^, <<, >>

Logical operators: not, or, and

Membership Operators: in, not in

Identity Operators: is, is not

### 5. Function And Arguements


```python
def fun(a, b, c=20, *args, **kwargs): # Required arguments， Default arguments， Variable-length arguments
    print 'a =', a, ' b =', b, ' c =', c, ' args >>>', args, ' kwargs >>>',kwargs
```


```python
fun()
```


    ---------------------------------------------------------------------------

    TypeError                                 Traceback (most recent call last)

    <ipython-input-13-d9f830ba61f1> in <module>()
    ----> 1 fun()
    

    TypeError: fun() takes at least 2 arguments (0 given)



```python
fun(1, 2)
```

    a = 1  b = 2  c = 20  args >>> ()  kwargs >>> {}
    


```python
fun(b=2, a=1)
```

    a = 1  b = 2  c = 20  args >>> ()  kwargs >>> {}
    


```python
fun(1, 2, 3, 4, 5)
```

    a = 1  b = 2  c = 3  args >>> (4, 5)  kwargs >>> {}
    


```python
fun(1, 2, 3, k='key', n='num')
```

    a = 1  b = 2  c = 3  args >>> ()  kwargs >>> {'k': 'key', 'n': 'num'}
    

### 6. Control

BTW, break/continue can be used as usual. 

if [-elif-else]:

    if condition1:
        statement1
    elif condition2:
        statement2
    else:
        statement3
while [-else]:

    while condition:
        statement1
    else：
        statement2
for [-else]:

    for variable in sequence:
        statement1
    else:
        statement2
### 7. IO Of File
![IO](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/IO.png?raw=true "IO")


```python
f = open(r'F:\Git\DataProcessingWithPython\The Zen Of Python.txt', 'r')
content = f.read()
print f.tell()
f.close()# When you’re done with a file, call f.close() to close it and free up any system resources taken up by the open file.
```

    233
    


```python
print content
```

    Beautiful is better than ugly.
    
    Explicit is better than implicit.
    
    Simple is better than complex.
    
    Complex is better than complicated.
    
    Flat is better than nested.
    
    Sparse is better than dense.
    
    Readability counts.
    
    ...
    


```python
f.readlines()
```


    ---------------------------------------------------------------------------

    ValueError                                Traceback (most recent call last)

    <ipython-input-20-055d0c37aeda> in <module>()
    ----> 1 f.readlines()
    

    ValueError: I/O operation on closed file



```python
with open(r'F:\Git\DataProcessingWithPython\The Zen Of Python.txt', 'r') as f: # without f.close() is OK
    print f.tell()
    c1 = f.readline()
    print f.tell()
```

    0
    32
    


```python
print c1
```

    Beautiful is better than ugly.
    
    


```python
with open(r'F:\Git\DataProcessingWithPython\The Zen Of Python.txt', 'r') as f:
    f.seek(34, 0)
    c2 = f.readline()
    print f.tell()
```

    69
    


```python
print c2
```

    Explicit is better than implicit.
    
    


```python
content
```




    'Beautiful is better than ugly.\n\nExplicit is better than implicit.\n\nSimple is better than complex.\n\nComplex is better than complicated.\n\nFlat is better than nested.\n\nSparse is better than dense.\n\nReadability counts.\n\n...'



## IV. "Talk is cheap. Show me the code."
### 1. Sequence
Sequence share below methods


```python
list_ = ['Fibonacci', 1, 1, 2, 3, 5, 8] # list
str_ = 'Hello' # str
tuple_ = (10, 'a') # tuple
```


```python
list_[1:6] # list_[start:end:step]
```




    [1, 1, 2, 3, 5]




```python
list_[::-1]
```




    [8, 5, 3, 2, 1, 1, 'Fibonacci']




```python
tuple_ * 3
```




    (10, 'a', 10, 'a', 10, 'a')




```python
str_ + ' Word!'
```




    'Hello Word!'




```python
'i' in 'Fibonacci'
```




    True




```python
len('Fibonacci')
```




    9




```python
', '.join(['a', 'b', 'c', 'd', 'e'])
```




    'a, b, c, d, e'



Something interesting


```python
'a-b-c-d-e'.split('-')
```




    ['a', 'b', 'c', 'd', 'e']




```python
'Emmmmm'.strip('m')
```




    'E'




```python
'Data Processing With Python'.istitle()
```




    True




```python
'A'.islower()
```




    False




```python
r'F:\Lab\preset'
```




    'F:\\Lab\\preset'



*"In Python, it’s all about the attributes. "*


```python
dir('Python')
```




    ['__add__',
     '__class__',
     '__contains__',
     '__delattr__',
     '__doc__',
     '__eq__',
     '__format__',
     '__ge__',
     '__getattribute__',
     '__getitem__',
     '__getnewargs__',
     '__getslice__',
     '__gt__',
     '__hash__',
     '__init__',
     '__le__',
     '__len__',
     '__lt__',
     '__mod__',
     '__mul__',
     '__ne__',
     '__new__',
     '__reduce__',
     '__reduce_ex__',
     '__repr__',
     '__rmod__',
     '__rmul__',
     '__setattr__',
     '__sizeof__',
     '__str__',
     '__subclasshook__',
     '_formatter_field_name_split',
     '_formatter_parser',
     'capitalize',
     'center',
     'count',
     'decode',
     'encode',
     'endswith',
     'expandtabs',
     'find',
     'format',
     'index',
     'isalnum',
     'isalpha',
     'isdigit',
     'islower',
     'isspace',
     'istitle',
     'isupper',
     'join',
     'ljust',
     'lower',
     'lstrip',
     'partition',
     'replace',
     'rfind',
     'rindex',
     'rjust',
     'rpartition',
     'rsplit',
     'rstrip',
     'split',
     'splitlines',
     'startswith',
     'strip',
     'swapcase',
     'title',
     'translate',
     'upper',
     'zfill']




```python
'Python'.__len__() # len('Python')
```




    6




```python
import os

dir1 = 'F:\Git\DataProcessingWithPython\exammode.db' #复制文件所在目录+手动输入DB文件名
dir2 = '‪‪F:\Git\DataProcessingWithPython\exammode.db' #文件属性/安全/对象名称获取的路径

os.path.exists(dir1), os.path.exists(dir2) 
```




    (True, False)




```python
hex(dir1.__hash__()), hex(dir2.__hash__())
```




    ('0x7466e790', '-0x4d1c4926')




```python
import chardet

chardet.detect(dir1), chardet.detect(dir2)
```




    ({'confidence': 1.0, 'encoding': 'ascii', 'language': ''},
     {'confidence': 0.7525, 'encoding': 'utf-8', 'language': ''})



### 2. Traversal


```python
range(5) # equal to range(0, 5, 1), [0, 5)
```




    [0, 1, 2, 3, 4]




```python
top5 = ['Java', 'C', 'C++', 'Python', 'C#']
for item in top5:
    print item
```

    Java
    C
    C++
    Python
    C#
    


```python
for item in sorted(top5):
    print item
```

    C
    C#
    C++
    Java
    Python
    


```python
for item in reversed(top5):
    print item
```

    C#
    Python
    C++
    C
    Java
    


```python
top5
```




    ['Java', 'C', 'C++', 'Python', 'C#']




```python
for offset, item in enumerate(top5):
    print offset, '>>>', item
```

    0 >>> Java
    1 >>> C
    2 >>> C++
    3 >>> Python
    4 >>> C#
    


```python
dic = dict(enumerate(top5))
dic
```




    {0: 'Java', 1: 'C', 2: 'C++', 3: 'Python', 4: 'C#'}




```python
dic = dict(zip(range(5), top5))
dic
```




    {0: 'Java', 1: 'C', 2: 'C++', 3: 'Python', 4: 'C#'}




```python
for key, value in dic.iteritems():
    print key, '>>>', value
```

    0 >>> Java
    1 >>> C
    2 >>> C++
    3 >>> Python
    4 >>> C#
    


```python
for x, y, z in zip([10, 11, 12], 'ABC', ('1010', '1011', '1100')):
    print 'DEC:', x, ' HEX:', y, ' BIN:', z
```

    DEC: 10  HEX: A  BIN: 1010
    DEC: 11  HEX: B  BIN: 1011
    DEC: 12  HEX: C  BIN: 1100
    

### 3. "Pythonic" Code


```python
0.1 < 0.3 < 0.5
```




    True




```python
a, b, c = 'ABC', 456, ('a')
print 'a =', a
print 'b =', b
print 'c =', c
```

    a = ABC
    b = 456
    c = a
    


```python
x = 1
y = 0
x, y = y, x
print 'x = ', x
print 'y = ', y
```

    x =  0
    y =  1
    


```python
s = '''CREATE TABLE "schema_version" (
    "name" TEXT NOT NULL PRIMARY KEY,
    "version" INTEGER NOT NULL,
    "migration" INTEGER NOT NULL);'''
print(s)
```

    CREATE TABLE "schema_version" (
        "name" TEXT NOT NULL PRIMARY KEY,
        "version" INTEGER NOT NULL,
        "migration" INTEGER NOT NULL);
    


```python
[x for x in range(18) if x % 2 == 1]
```




    [1, 3, 5, 7, 9, 11, 13, 15, 17]




```python
fun = lambda str_:str_.lower() # lambda
fun('AbCdE')
```




    'abcde'




```python
map(str.upper, 'Hello Word!') # map
```




    ['H', 'E', 'L', 'L', 'O', ' ', 'W', 'O', 'R', 'D', '!']




```python
filter(str.isupper, 'Hello Word!') # filter
```




    'HW'




```python
reduce(lambda x,y:x*y, [1, 2, 3, 4, 5]) # reduce, to caculate 5!
```




    120




```python
isinstance('Hello Word!', str) # isinstance
```




    True



## V. Packages We Use
[SciPy](https://www.scipy.org/!) (pronounced “Sigh Pie”) is a Python-based ecosystem of open-source software for **mathematics**, **science**, and **engineering**. 
### 1. Pandas
![pandasLogo](http://pandas.pydata.org/_static/pandas_logo.png "pandasLogo")
Pandas (Python Data Analysis Library) is an open source, BSD-licensed library providing high-performance, easy-to-use **data structures** and **data analysis tools** for the Python programming language. 
### 2. Numpy
![numpyLogo](http://www.numpy.org/_static/numpy_logo.png "numpyLogo")
NumPy is the fundamental package for **scientific computing** with Python. It contains among other things: 

* a powerful N-dimensional array object


* tools for integrating C/C++ and Fortran code


* useful linear algebra, Fourier transform, and random number capabilities

...
### 3. Matplotlib
![matplotlibLogo](https://matplotlib.org/_static/logo2.png "matplotlibLogo")
![matplotlib](https://upload.wikimedia.org/wikipedia/commons/thumb/c/ca/Mpl_screenshot_figures_and_code.png/300px-Mpl_screenshot_figures_and_code.png "matplotlib")
Matplotlib is a Python **2D plotting library** which produces **publication quality figures** in a variety of hardcopy formats and interactive environments across platforms. 
### 4. IPython
![ipythonLogo](http://ipython.org/_static/IPy_header.png "piythonLogo")
![ipython](http://ipython.org/_static/ipy_0.13.png "ipython")
In 2014, Fernando Pérez announced a spin-off project from IPython called *Project Jupyter*. IPython will continue to exist as a Python shell and a kernel for Jupyter, while the notebook and other language-agnostic parts of IPython will move under the Jupyter name. Jupyter added support for **Julia**, **R**, **Haskell** and **Ruby**. 
![jupyterLogo](http://jupyter.org/assets/nav_logo.svg "jupyterLogo")
![jupyter](https://jupyter.org/assets/jupyterpreview.png "jupyter")
### 5. Scipy
![scipyLogo](https://www.scipy.org/_static/logo.gif "scipyLogo")
The SciPy library is one of the core packages that make up the SciPy stack. It provides many user-friendly and efficient numerical routines such as routines for numerical integration and optimization. 

* constants: physical constants and conversion factors


* cluster: hierarchical clustering, vector quantization, K-means


* fftpack: Discrete Fourier Transform algorithms


* optimize: optimization algorithms including linear programming


* signal: signal processing tools


* ndimage: various functions for multi-dimensional image processing


* sparse: sparse matrix and related algorithms

...

## VI. Pandas
### 1. Library Highlights
* A fast and efficient **DataFrame** object for data manipulation with integrated indexing
* Tools for **reading and writing data** between in-memory data structures and different formats: CSV and text files, Microsoft Excel, SQL databases, and the fast HDF5 format
* Flexible **reshaping and pivoting** of data sets
* Highly optimized for performance, with critical code paths written in **Cython or C**
* High performance **merging and joining** of data sets

...

### 2. DataFrame
![DataFrame](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/DataFrame.png?raw=true "DataFrame") 


```python
import pandas as pd

examModeTable = pd.read_excel(r'F:\Git\DataProcessingWithPython\ExamModeSpec.xlsx', header=3)
examModeTable.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Product</th>
      <th>Purpose</th>
      <th>Application</th>
      <th>Chinese</th>
      <th>Abbreviation</th>
      <th>English</th>
      <th>AppField</th>
      <th>App2Exam</th>
      <th>Unnamed: 8</th>
      <th>Unnamed: 9</th>
      <th>...</th>
      <th>Unnamed: 63</th>
      <th>Unnamed: 64</th>
      <th>Unnamed: 65</th>
      <th>Unnamed: 66</th>
      <th>Unnamed: 67</th>
      <th>Unnamed: 68</th>
      <th>Unnamed: 69</th>
      <th>Unnamed: 70</th>
      <th>Unnamed: 71</th>
      <th>Unnamed: 72</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>NaN</th>
      <td>#</td>
      <td>#</td>
      <td>#</td>
      <td>#</td>
      <td>#</td>
      <td>#</td>
      <td>#</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>测量</td>
      <td>注释</td>
      <td>体位图</td>
      <td>报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>GENERAL</td>
      <td>系统测试</td>
      <td>SysTest</td>
      <td>System Test</td>
      <td>ABD</td>
      <td>NaN</td>
      <td>√</td>
      <td>0.0</td>
      <td>...</td>
      <td>0.0</td>
      <td>√</td>
      <td>0.0</td>
      <td>√</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>ABD</td>
      <td>Abdomen</td>
      <td>Abdomen</td>
      <td>腹部超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>GENERAL</td>
      <td>成人腹部</td>
      <td>Adult ABD</td>
      <td>Adult Abdominal</td>
      <td>ABD</td>
      <td>√</td>
      <td>Default</td>
      <td>0.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>√</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>CAR</td>
      <td>Cardiac</td>
      <td>Cardiology</td>
      <td>心脏超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>*</td>
      <td>成人心脏</td>
      <td>Adult Cardiac</td>
      <td>Adult Cardiac</td>
      <td>Cardiac</td>
      <td>√</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>...</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>GYN</td>
      <td>Gyn</td>
      <td>Gyn</td>
      <td>妇科超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>*</td>
      <td>妇科</td>
      <td>GYN</td>
      <td>GYN</td>
      <td>GYN</td>
      <td>√</td>
      <td>√</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>Default[ANE]</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>OB1</td>
      <td>OB</td>
      <td>OB</td>
      <td>产科超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>GENERAL</td>
      <td>早孕</td>
      <td>OB1</td>
      <td>OB1</td>
      <td>OB</td>
      <td>NaN</td>
      <td>√</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>Default</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>OB2/3</td>
      <td>OB</td>
      <td>OB</td>
      <td>产科超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>GENERAL</td>
      <td>中晚孕</td>
      <td>OB2/3</td>
      <td>OB2/3</td>
      <td>OB</td>
      <td>√</td>
      <td>√</td>
      <td>1.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>√</td>
      <td>1.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>OB2/3</td>
      <td>OB</td>
      <td>OB</td>
      <td>产科超声报告</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>*</td>
      <td>HUMAN</td>
      <td>GENERAL</td>
      <td>胎儿心脏</td>
      <td>Fetal Cardiac</td>
      <td>Fetal Cardiac</td>
      <td>OB</td>
      <td>NaN</td>
      <td>√</td>
      <td>2.0</td>
      <td>...</td>
      <td>NaN</td>
      <td>√</td>
      <td>2.0</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>NaN</td>
      <td>URO</td>
      <td>Kidney</td>
      <td>Kidney</td>
      <td>泌尿超声报告</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 73 columns</p>
</div>




```python
examModeTable = examModeTable.ix[:, ['Chinese', 'Abbreviation']]
examModeTable.head(8)
```

    d:\python\lib\site-packages\ipykernel_launcher.py:1: DeprecationWarning: 
    .ix is deprecated. Please use
    .loc for label based indexing or
    .iloc for positional indexing
    
    See the documentation here:
    http://pandas.pydata.org/pandas-docs/stable/indexing.html#ix-indexer-is-deprecated
      """Entry point for launching an IPython kernel.
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Chinese</th>
      <th>Abbreviation</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>NaN</th>
      <td>#</td>
      <td>#</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>系统测试</td>
      <td>SysTest</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>成人腹部</td>
      <td>Adult ABD</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>成人心脏</td>
      <td>Adult Cardiac</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>妇科</td>
      <td>GYN</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>早孕</td>
      <td>OB1</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>中晚孕</td>
      <td>OB2/3</td>
    </tr>
    <tr>
      <th>NaN</th>
      <td>胎儿心脏</td>
      <td>Fetal Cardiac</td>
    </tr>
  </tbody>
</table>
</div>




```python
examModeId = pd.read_csv((r'F:\Git\DataProcessingWithPython\examid.txt'), header=None, names=['Abbreviation', 'examModeId'])
examModeId.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Abbreviation</th>
      <th>examModeId</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adult ABD</td>
      <td>c5ddb1fa-704b-31b2-9510-2e75bdd16fee</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adult Cardiac</td>
      <td>5cbcf239-7c62-3bb9-bb15-c24429d60d84</td>
    </tr>
    <tr>
      <th>2</th>
      <td>GYN</td>
      <td>48957ed3-634a-3c70-9444-9de798b771df</td>
    </tr>
    <tr>
      <th>3</th>
      <td>OB1</td>
      <td>b2c27741-5fc1-3bd1-a097-90e0cbc95a11</td>
    </tr>
    <tr>
      <th>4</th>
      <td>OB2/3</td>
      <td>015b044d-b456-375f-86f1-280987bbc6d1</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Fetal Cardiac</td>
      <td>bc00dae4-8072-39f1-bd6d-4d011f6392b6</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Kidney</td>
      <td>7bcd41db-96d1-3b94-af58-b951d03951eb</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Prostate</td>
      <td>34882457-b208-3dba-9aa4-49cb38f0aff9</td>
    </tr>
  </tbody>
</table>
</div>




```python
examModeTable = pd.merge(examModeId, examModeTable, on='Abbreviation')
examModeTable.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Abbreviation</th>
      <th>examModeId</th>
      <th>Chinese</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>Adult ABD</td>
      <td>c5ddb1fa-704b-31b2-9510-2e75bdd16fee</td>
      <td>成人腹部</td>
    </tr>
    <tr>
      <th>1</th>
      <td>Adult Cardiac</td>
      <td>5cbcf239-7c62-3bb9-bb15-c24429d60d84</td>
      <td>成人心脏</td>
    </tr>
    <tr>
      <th>2</th>
      <td>GYN</td>
      <td>48957ed3-634a-3c70-9444-9de798b771df</td>
      <td>妇科</td>
    </tr>
    <tr>
      <th>3</th>
      <td>OB1</td>
      <td>b2c27741-5fc1-3bd1-a097-90e0cbc95a11</td>
      <td>早孕</td>
    </tr>
    <tr>
      <th>4</th>
      <td>OB2/3</td>
      <td>015b044d-b456-375f-86f1-280987bbc6d1</td>
      <td>中晚孕</td>
    </tr>
    <tr>
      <th>5</th>
      <td>Fetal Cardiac</td>
      <td>bc00dae4-8072-39f1-bd6d-4d011f6392b6</td>
      <td>胎儿心脏</td>
    </tr>
    <tr>
      <th>6</th>
      <td>Kidney</td>
      <td>7bcd41db-96d1-3b94-af58-b951d03951eb</td>
      <td>肾脏</td>
    </tr>
    <tr>
      <th>7</th>
      <td>Prostate</td>
      <td>34882457-b208-3dba-9aa4-49cb38f0aff9</td>
      <td>前列腺</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = pd.read_csv(r'F:\Git\DataProcessingWithPython\imgPara.csv', encoding='gb2312').ix[:, ['probeName', 'Chinese', 'imgParaName', 'imgParaVal']]
df.head(8)
```

    d:\python\lib\site-packages\ipykernel_launcher.py:1: DeprecationWarning: 
    .ix is deprecated. Please use
    .loc for label based indexing or
    .iloc for positional indexing
    
    See the documentation here:
    http://pandas.pydata.org/pandas-docs/stable/indexing.html#ix-indexer-is-deprecated
      """Entry point for launching an IPython kernel.
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>probeName</th>
      <th>Chinese</th>
      <th>imgParaName</th>
      <th>imgParaVal</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxPW_Map</td>
      <td>2</td>
    </tr>
    <tr>
      <th>1</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxD2d_Sensitivity_P</td>
      <td>3</td>
    </tr>
    <tr>
      <th>2</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>UIC_Baseline</td>
      <td>10</td>
    </tr>
    <tr>
      <th>3</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxM_Map</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxTis</td>
      <td>2</td>
    </tr>
    <tr>
      <th>5</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxD2d_Scale</td>
      <td>0</td>
    </tr>
    <tr>
      <th>6</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>IdxPW_WF_CW</td>
      <td>98</td>
    </tr>
    <tr>
      <th>7</th>
      <td>L10-5</td>
      <td>乳腺</td>
      <td>UID_BaseLine_CW</td>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df.set_index(['probeName', 'Chinese', 'imgParaName'])
df.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th></th>
      <th></th>
      <th>imgParaVal</th>
    </tr>
    <tr>
      <th>probeName</th>
      <th>Chinese</th>
      <th>imgParaName</th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="8" valign="top">L10-5</th>
      <th rowspan="8" valign="top">乳腺</th>
      <th>IdxPW_Map</th>
      <td>2</td>
    </tr>
    <tr>
      <th>IdxD2d_Sensitivity_P</th>
      <td>3</td>
    </tr>
    <tr>
      <th>UIC_Baseline</th>
      <td>10</td>
    </tr>
    <tr>
      <th>IdxM_Map</th>
      <td>0</td>
    </tr>
    <tr>
      <th>IdxTis</th>
      <td>2</td>
    </tr>
    <tr>
      <th>IdxD2d_Scale</th>
      <td>0</td>
    </tr>
    <tr>
      <th>IdxPW_WF_CW</th>
      <td>98</td>
    </tr>
    <tr>
      <th>UID_BaseLine_CW</th>
      <td>4</td>
    </tr>
  </tbody>
</table>
</div>




```python
df = df.unstack()
df.head(8)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead tr th {
        text-align: left;
    }

    .dataframe thead tr:last-of-type th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr>
      <th></th>
      <th></th>
      <th colspan="21" halign="left">imgParaVal</th>
    </tr>
    <tr>
      <th></th>
      <th>imgParaName</th>
      <th>IdxAMM_Speed</th>
      <th>IdxB_Colorize</th>
      <th>IdxB_Depth</th>
      <th>IdxB_ExtFOV</th>
      <th>IdxB_FOVPercent</th>
      <th>IdxB_FUND_Opt</th>
      <th>IdxB_LineDensity</th>
      <th>IdxB_Map</th>
      <th>IdxB_Persist</th>
      <th>IdxB_Steer</th>
      <th>...</th>
      <th>ecg_2d_speed</th>
      <th>ecg_gain</th>
      <th>ecg_y_pos</th>
      <th>harmonic</th>
      <th>middleline</th>
      <th>mode_3d_image_layout</th>
      <th>pw_multiplex</th>
      <th>thermal_index</th>
      <th>timemark</th>
      <th>viewscale</th>
    </tr>
    <tr>
      <th>probeName</th>
      <th>Chinese</th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
      <th></th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th rowspan="8" valign="top">C5-1</th>
      <th>ICU</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>9.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>中晚孕</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>9.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>前列腺</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>妇科</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>9.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>小儿腹部</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>7.0</td>
      <td>0.0</td>
      <td>2.0</td>
      <td>4.0</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>3.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>急诊FAST</th>
      <td>NaN</td>
      <td>1.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>9.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>成人腹部</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>10.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>1.0</td>
      <td>2.0</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
    <tr>
      <th>早孕</th>
      <td>NaN</td>
      <td>0.0</td>
      <td>9.0</td>
      <td>0.0</td>
      <td>3.0</td>
      <td>3.0</td>
      <td>2.0</td>
      <td>9.0</td>
      <td>4.0</td>
      <td>0.0</td>
      <td>...</td>
      <td>5.0</td>
      <td>1.0</td>
      <td>20.0</td>
      <td>1.0</td>
      <td>0.0</td>
      <td>NaN</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>0.0</td>
      <td>1.0</td>
    </tr>
  </tbody>
</table>
<p>8 rows × 251 columns</p>
</div>



![stack](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/stack.png?raw=true "stack")
## VII. Numpy And Matplotlib


```python
import numpy as np
import matplotlib.pyplot as plt
```


```python
a = np.array([[0, -1, 2], (3, 4, -5), [-6, 7, 8], (-9, 10, 11)])
a
```




    array([[ 0, -1,  2],
           [ 3,  4, -5],
           [-6,  7,  8],
           [-9, 10, 11]])




```python
a[1:3, 0:2]
```




    array([[ 3,  4],
           [-6,  7]])




```python
a.shape
```




    (4, 3)




```python
a.T
```




    array([[ 0,  3, -6, -9],
           [-1,  4,  7, 10],
           [ 2, -5,  8, 11]])




```python
a.sum()
```




    24




```python
a.reshape(6, 2)
```




    array([[ 0, -1],
           [ 2,  3],
           [ 4, -5],
           [-6,  7],
           [ 8, -9],
           [10, 11]])




```python
a >= 0
```




    array([[ True, False,  True],
           [ True,  True, False],
           [False,  True,  True],
           [False,  True,  True]])




```python
a * (a >= 0)
```




    array([[ 0,  0,  2],
           [ 3,  4,  0],
           [ 0,  7,  8],
           [ 0, 10, 11]])




```python
np.zeros([2, 6])
```




    array([[0., 0., 0., 0., 0., 0.],
           [0., 0., 0., 0., 0., 0.]])




```python
np.ones((2, 3, 4), dtype=np.int8) # dtype can also be specified
```




    array([[[1, 1, 1, 1],
            [1, 1, 1, 1],
            [1, 1, 1, 1]],
    
           [[1, 1, 1, 1],
            [1, 1, 1, 1],
            [1, 1, 1, 1]]], dtype=int8)




```python
np.linspace(0, np.pi, 4)
```




    array([0.        , 1.04719755, 2.0943951 , 3.14159265])




```python
np.arange(10, 30, 5)
```




    array([10, 15, 20, 25])




```python
x = np.random.rand(1000)
y = np.random.rand(1000)
size = np.random.rand(1000) * 50
colour = np.random.rand(1000)
plt.scatter(x, y, size, colour)
plt.colorbar()
plt.show()
```


![png](output_99_0.png)



```python
x = np.random.randn(1000)
plt.hist(x, 50)
plt.show()
```


![png](output_100_0.png)


## VIII. Jupyter Notebook


```python
# top5?
# fun??
```


```python
%timeit range(1000)
```

    100000 loops, best of 3: 7.35 µs per loop
    


```python
%pwd
```




    u'F:\\OneDrive\\Python'




```python
%cd F:\Git\DataProcessingWithPython
%pwd
```

    F:\Git\DataProcessingWithPython
    




    u'F:\\Git\\DataProcessingWithPython'




```python
!dir
```

     驱动器 F 中的卷是 File
     卷的序列号是 7AF9-E837
    
     F:\Git\DataProcessingWithPython 的目录
    
    2018/03/16 周五  17:31    <DIR>          .
    2018/03/16 周五  17:31    <DIR>          ..
    2018/03/15 周四  11:47           107,545 AnacondaApp.jpg
    2018/03/15 周四  11:45           303,106 AnacondaEnv.png
    2018/03/15 周四  14:09            31,974 AnacondaInstall.jpg
    2018/03/16 周五  17:24           531,494 Data Processing With Python.html
    2018/03/16 周五  17:30            32,361 Data Processing With Python.ipynb
    2018/03/07 周三  15:04            72,709 DataFrame.png
    2018/01/04 周四  16:30             2,171 drawFigure.py
    2018/01/31 周三  14:44             3,350 examid.txt
    2018/02/06 周二  11:20         1,884,160 exammode.db
    2018/02/12 周一  13:38            40,311 ExamModeSpec.xlsx
    2018/03/07 周三  15:38         1,888,815 imgPara.csv
    2018/03/06 周二  16:23             8,553 indexOfFeb2018.png
    2018/03/14 周三  18:03            67,445 IO.png
    2018/03/14 周三  14:43            26,576 languageStyle.png
    2018/03/06 周二  15:20             5,548 longTermHistory.png
    2018/03/15 周四  11:28           141,562 packagesManager.png
    2018/03/15 周四  14:06            40,803 py2install.png
    2018/03/15 周四  14:07            57,027 py3install.png
    2018/03/16 周五  15:28            30,601 pyinstaller.png
    2018/03/07 周三  15:57            73,927 stack.png
    2018/03/15 周四  09:20               233 The Zen Of Python.txt
                  21 个文件      5,350,271 字节
                   2 个目录 247,541,469,184 可用字节
    


```python
%run drawFigure.py
```


![png](output_107_0.png)



```python
JPEG_PSNR
```




    [28.8, 31.11, 32.79, 34.82, 29.99, 31.89, 30.83, 29.49]




```python
!ping 192.168.1.1
```

    
    正在 Ping 192.168.1.1 具有 32 字节的数据:
    来自 192.168.1.1 的回复: 字节=32 时间<1ms TTL=64
    来自 192.168.1.1 的回复: 字节=32 时间<1ms TTL=64
    来自 192.168.1.1 的回复: 字节=32 时间<1ms TTL=64
    来自 192.168.1.1 的回复: 字节=32 时间<1ms TTL=64
    
    192.168.1.1 的 Ping 统计信息:
        数据包: 已发送 = 4，已接收 = 4，丢失 = 0 (0% 丢失)，
    往返行程的估计时间(以毫秒为单位):
        最短 = 0ms，最长 = 0ms，平均 = 0ms
    

## IX. How To Get Python And Packages?
**[Python 2.X or 3.X?](https://wiki.python.org/moin/Python2orPython3)**
### 1. Average Coding
a) Download Python From [Official Website](https://www.python.org/downloads/)

b) Make Sure Python Has Been Added To PATH
![py2install](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/py2install.png?raw=true "py2install")
![py3install](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/py3install.png?raw=true "py3install")
c) [pip](https://pip.pypa.io/en/stable/quickstart/) (Preferred Installer Program) - Python Package Manager

Type In Console: pip install packageName

...
### 2. Coding For Data Science
![Anaconda](https://www.anaconda.com/wp-content/themes/anaconda/images/logo-dark.png "Anaconda")
**What And Why Anaconda?**

Anaconda - *"The Most Popular Python Data Science Platform"*

It includes hundreds of popular data science packages and the conda package and virtual environment manager for Windows, Linux, and MacOS. Conda makes it quick and easy to install, run, and upgrade complex data science and machine learning environments like Scikit-learn, TensorFlow, and SciPy. 

![AnacondaApp](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/AnacondaApp.jpg?raw=true "AnacondaApp")
![AnacondaEnv](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/AnacondaEnv.png?raw=true "AnacondaEnv")
a) Download Anaconda From [Official Website](https://www.anaconda.com/download/) Or [Tsinghua Mirrors](https://mirrors.tuna.tsinghua.edu.cn/anaconda/archive/)

b) Make Sure Python Has Been Added To PATH
![AnacondaInstall](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/AnacondaInstall.jpg?raw=true "AnacondaInstall")
c) conda
![packagesManager](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/packagesManager.png?raw=true "packagesManager")
![pyinstaller](https://github.com/NightMarcher/DataProcessingWithPython/blob/master/pyinstaller.png?raw=true "pyinstaller")

## X. How To Get Help When Coding?
1.type(), isinstance(), dir(), help(), print()


2.magic commands(with IPython): ?, ??


3.Google, Bing, Baidu...

---
## Let`s Play With Python
1.Change 'F:\\Git\\DataProcessingWithPython' into 'F:/Git/DataProcessingWithPython'

2.Print Fibonacci List(1, 1, 2, 3, 5, 8, 13...)
![FibonacciSpiral](https://upload.wikimedia.org/wikipedia/commons/thumb/2/2e/FibonacciSpiral.svg/354px-FibonacciSpiral.svg.png "FibonacciSpiral")

3.Fetch the number which can`t mod 3 get 0 from 1 to 50

![Think](http://www.hdwallpapers.in/walls/think_different-wide.jpg "Think")

**Think Twice, Think Different! o.O**
## Recommanded Solutions
1.Change 'F:\Git\DataProcessingWithPython' into 'F:/Git/DataProcessingWithPython'


```python
'/'.join('F:\\Git\\DataProcessingWithPython'.split('\\'))
```




    'F:/Git/DataProcessingWithPython'



2.Print Fibonacci Number(1, 1, 2, 3, 5, 8, 13...)


```python
a = 1
b = 1
for i in range(10):
    print a,
    a, b = b, a + b
```

    1 1 2 3 5 8 13 21 34 55
    

3.Fetch the number which can`t mod 3 get 0 from 1 to 50


```python
for i in range(0, 51):
    if i % 3:
        print i,
```

    1 2 4 5 7 8 10 11 13 14 16 17 19 20 22 23 25 26 28 29 31 32 34 35 37 38 40 41 43 44 46 47 49 50
    


```python
[x for x in range(1,51) if x % 3 != 0]
```




    [1,
     2,
     4,
     5,
     7,
     8,
     10,
     11,
     13,
     14,
     16,
     17,
     19,
     20,
     22,
     23,
     25,
     26,
     28,
     29,
     31,
     32,
     34,
     35,
     37,
     38,
     40,
     41,
     43,
     44,
     46,
     47,
     49,
     50]




```python
filter(lambda x:x not in range(0, 51, 3), range(0, 51))
```




    [1,
     2,
     4,
     5,
     7,
     8,
     10,
     11,
     13,
     14,
     16,
     17,
     19,
     20,
     22,
     23,
     25,
     26,
     28,
     29,
     31,
     32,
     34,
     35,
     37,
     38,
     40,
     41,
     43,
     44,
     46,
     47,
     49,
     50]




```python
np.array(range(1,51))[np.array(range(1,51)) % 3 != 0]
```




    array([ 1,  2,  4,  5,  7,  8, 10, 11, 13, 14, 16, 17, 19, 20, 22, 23, 25,
           26, 28, 29, 31, 32, 34, 35, 37, 38, 40, 41, 43, 44, 46, 47, 49, 50])



**You Can Download All Files From My [DataProcessingWithPython](https://github.com/NightMarcher/DataProcessingWithPython) Repositorie On GitHub. Thanks For Your Patience! **
